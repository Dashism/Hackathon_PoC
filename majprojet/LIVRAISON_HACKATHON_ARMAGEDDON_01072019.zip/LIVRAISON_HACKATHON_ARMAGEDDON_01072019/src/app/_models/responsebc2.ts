/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Responsebc2 {
    public Key: string;
    public Record: string;
}
