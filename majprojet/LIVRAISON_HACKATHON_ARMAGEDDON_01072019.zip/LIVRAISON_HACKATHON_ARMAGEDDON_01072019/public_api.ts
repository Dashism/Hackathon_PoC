export * from './src/app/modules/slideshow/slideshow.module';
export {IImage} from './src/app/modules/slideshow/IImage';
