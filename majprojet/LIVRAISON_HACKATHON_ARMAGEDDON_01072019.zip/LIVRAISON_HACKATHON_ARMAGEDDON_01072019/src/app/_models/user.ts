﻿export class User {
    // id: number;
    // username: string;
    // password: string;
    // firstName: string;
    // lastName: string;
    // token: string;
    id: number;
    name: string;
    firstname: string;
    email: string;
    mobile: string;
    username: string;
    password: string;
    token: string;
}