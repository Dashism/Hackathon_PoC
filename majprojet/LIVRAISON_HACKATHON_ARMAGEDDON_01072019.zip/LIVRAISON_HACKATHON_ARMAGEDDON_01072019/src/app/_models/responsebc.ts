/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Responsebc {
    public response: string;
}
