/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Diploma {
    public docType?: string;
    public diplomaid?: string;
    public username: string;
    public diplomaname: string;
}
