/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Projectskill {
    public docType?: string;
    public projectskillid?: string;
    public ausername?: string;
    public bskillname?: string;
    public clevel?: string;
    public username: string;
    public projectname: string;
    public skillname: string;
    public level: string;
}
