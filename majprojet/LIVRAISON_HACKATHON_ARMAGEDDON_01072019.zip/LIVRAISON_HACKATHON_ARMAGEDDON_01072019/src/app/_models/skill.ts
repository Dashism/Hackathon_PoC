/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Skill {
    public docType?: string;
    public skillid?: string;
    public ausername?: string;
    public bskillname?: string;
    public clevel?: string;
    public username: string;
    public skillname: string;
    public level: string;
    public grade: string;
}